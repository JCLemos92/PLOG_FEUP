------------Outside Sudoku...................
Jo�o Carlos Fonseca Pina de Lemos - up201000660
Lu�s Guilherme da Costa Castro Neves - up201306485
FEUP - PLOG - 3MIEIC01 - Outside_Sudoku_2

Compile on main.pl
To solve outside sudoku do solve(X) X in 1 ... 5
To solve sudoku* do solve_sudoku(X) X in 1 ... 7
 
*Not required for the project but was 1st developed as a study, it isn't at all well made.